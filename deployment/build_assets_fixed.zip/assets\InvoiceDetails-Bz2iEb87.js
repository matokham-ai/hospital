import{r,aO as W,O as F,ai as X,j as e,K as Y,L as J,a3 as ee,be as k,aK as P,ae as te,a0 as S,b3 as se,at as I,ab as ae,bf as re,bd as o,aa as le,bg as D,a9 as ne,bh as ie,bi as de,aI as _,bj as oe,A as ce}from"./react-vendor-CB1DGefZ.js";import{H as xe}from"./HMSLayout-CLkqOFxR.js";import"./vendor-CR1Hpai0.js";import"./charts-BWFwqYwz.js";import"./framer-motion-BvyGw6a9.js";const c={paid:{label:"Paid",color:"bg-green-100 text-green-800 border-green-200",icon:X},partial:{label:"Partially Paid",color:"bg-yellow-100 text-yellow-800 border-yellow-200",icon:F},unpaid:{label:"Unpaid",color:"bg-red-100 text-red-800 border-red-200",icon:W}},C={consultation:"🩺",laboratory:"🔬",radiology:"📡",pharmacy:"💊",accommodation:"🛏️",procedure:"⚕️",default:"📋"};function fe({invoice:t,items:x,payments:l}){const[L,m]=r.useState(!1),[K,h]=r.useState(!1),[z,p]=r.useState(!1),[A,g]=r.useState(""),[n,b]=r.useState(null),[i,f]=r.useState(!1),[d,u]=r.useState(120),$=c[t.status]?.icon||F,B=c[t.status]?.color||"bg-gray-100 text-gray-800 border-gray-200",j=c[t.status]?.label||t.status,y=t.total_amount>0?t.paid_amount/t.total_amount*100:0,N=async s=>{f(!0);try{const a=document.getElementById("invoice-content");if(!a)throw new Error("Invoice content not found");const Q={margin:[.3,.3,.3,.3],filename:`Invoice_${t.id}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0},jsPDF:{unit:"in",format:"a4",orientation:"portrait"}},v=html2pdf().set(Q).from(a);if(s==="download")await v.save();else{const V=await v.output("blob");b(V),m(!0)}}catch(a){console.error("PDF generation failed:",a),alert("PDF preview could not be generated.")}finally{f(!1)}},H=()=>{N("preview")},E=()=>{N("download")},T=()=>{if(n){const s=URL.createObjectURL(n),a=document.createElement("a");a.href=s,a.download=`Invoice_${t.id}.pdf`,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(s)}},O=()=>{m(!1),b(null)},R=()=>{h(!0)},M=()=>{h(!1),u(120)},U=()=>{const s=window.open("","_blank");if(s){const a=document.getElementById("invoice-content")?.innerHTML;s.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Invoice #${t.id}</title>
            <style>
              * { box-sizing: border-box; margin: 0; padding: 0; }
              body { 
                font-family: system-ui, -apple-system, sans-serif; 
                line-height: 1.5; 
                color: #1f2937;
                background: white;
                padding: 20px;
                margin: 0;
              }
              .bg-gradient-to-r { background: #f9fafb !important; }
              .rounded-2xl { border-radius: 8px; border: 1px solid #e5e7eb; }
              .shadow-sm { box-shadow: none; }
              .p-6 { padding: 16px; }
              .space-y-4 > * + * { margin-top: 16px; }
              .space-y-3 > * + * { margin-top: 12px; }
              .space-y-6 > * + * { margin-top: 24px; }
              .grid { display: grid; }
              .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
              .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
              .lg\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
              .gap-4 { gap: 16px; }
              .gap-6 { gap: 24px; }
              .gap-8 { gap: 32px; }
              .flex { display: flex; }
              .items-center { align-items: center; }
              .justify-between { justify-content: space-between; }
              .justify-center { justify-content: center; }
              .space-x-2 > * + * { margin-left: 8px; }
              .space-x-3 > * + * { margin-left: 12px; }
              .space-x-4 > * + * { margin-left: 16px; }
              .text-xl { font-size: 1.25rem; }
              .text-lg { font-size: 1.125rem; }
              .text-sm { font-size: 0.875rem; }
              .text-xs { font-size: 0.75rem; }
              .font-bold { font-weight: 700; }
              .font-semibold { font-weight: 600; }
              .font-medium { font-weight: 500; }
              .text-gray-900 { color: #111827; }
              .text-gray-600 { color: #4b5563; }
              .text-gray-500 { color: #6b7280; }
              .text-gray-400 { color: #9ca3af; }
              .text-red-600 { color: #dc2626; }
              .text-green-600 { color: #16a34a; }
              .text-teal-600 { color: #0d9488; }
              .bg-blue-500 { background-color: #3b82f6; }
              .bg-teal-600 { background-color: #0d9488; }
              .bg-gray-50 { background-color: #f9fafb; }
              .bg-gray-100 { background-color: #f3f4f6; }
              .bg-white { background-color: white; }
              .text-white { color: white; }
              .w-12 { width: 3rem; }
              .h-12 { width: 3rem; height: 3rem; }
              .w-16 { width: 4rem; }
              .h-16 { width: 4rem; height: 4rem; }
              .w-4 { width: 1rem; }
              .h-4 { width: 1rem; height: 1rem; }
              .w-6 { width: 1.5rem; }
              .h-6 { width: 1.5rem; height: 1.5rem; }
              .w-8 { width: 2rem; }
              .h-8 { width: 2rem; height: 2rem; }
              .rounded-full { border-radius: 9999px; }
              .rounded-lg { border-radius: 8px; }
              .border { border: 1px solid #e5e7eb; }
              .border-t { border-top: 1px solid #e5e7eb; }
              .border-b { border-bottom: 1px solid #e5e7eb; }
              .border-gray-200 { border-color: #e5e7eb; }
              .border-teal-100 { border-color: #ccfbf1; }
              .pt-3 { padding-top: 12px; }
              .mt-1 { margin-top: 4px; }
              .mt-2 { margin-top: 8px; }
              .mt-6 { margin-top: 24px; }
              .mb-3 { margin-bottom: 12px; }
              .mb-4 { margin-bottom: 16px; }
              .uppercase { text-transform: uppercase; }
              .capitalize { text-transform: capitalize; }
              .text-right { text-align: right; }
              .text-center { text-align: center; }
              .text-left { text-align: left; }
              .overflow-x-auto { overflow-x: auto; }
              .min-w-full { min-width: 100%; }
              .divide-y { border-collapse: collapse; }
              .divide-gray-200 > * + * { border-top: 1px solid #e5e7eb; }
              .px-6 { padding-left: 24px; padding-right: 24px; }
              .py-3 { padding-top: 12px; padding-bottom: 12px; }
              .py-4 { padding-top: 16px; padding-bottom: 16px; }
              .py-8 { padding-top: 32px; padding-bottom: 32px; }
              .whitespace-nowrap { white-space: nowrap; }
              .tracking-wider { letter-spacing: 0.05em; }
              table { width: 100%; border-collapse: collapse; }
              th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
              th { background-color: #f9fafb; font-weight: 600; }
              tr:nth-child(even) { background-color: #f9fafb; }
              .inline-flex { display: inline-flex; }
              .px-3 { padding-left: 12px; padding-right: 12px; }
              .py-1 { padding-top: 4px; padding-bottom: 4px; }
              .rounded-full { border-radius: 9999px; }
              .bg-green-100 { background-color: #dcfce7; }
              .text-green-800 { color: #166534; }
              .border-green-200 { border-color: #bbf7d0; }
              .bg-yellow-100 { background-color: #fef3c7; }
              .text-yellow-800 { color: #92400e; }
              .border-yellow-200 { border-color: #fde68a; }
              .bg-red-100 { background-color: #fee2e2; }
              .text-red-800 { color: #991b1b; }
              .border-red-200 { border-color: #fecaca; }
              .w-full { width: 100%; }
              .h-3 { height: 12px; }
              .bg-gray-200 { background-color: #e5e7eb; }
              .bg-gradient-to-r { background: linear-gradient(to right, #3b82f6, #10b981); }
              .from-blue-500 { --tw-gradient-from: #3b82f6; }
              .to-green-500 { --tw-gradient-to: #10b981; }
              .from-gray-50 { background: #f9fafb; }
              .to-gray-100 { background: #f3f4f6; }
              .from-teal-50 { background: #f0fdfa; }
              .to-blue-50 { background: #eff6ff; }
              @media print {
                body { margin: 0; padding: 15px; }
                .no-print { display: none !important; }
              }
            </style>
          </head>
          <body>
            ${a}
          </body>
        </html>
      `),s.document.close(),s.focus(),s.print(),s.close()}},w=s=>{u(a=>s==="in"&&a<150?a+10:s==="out"&&a>50?a-10:a)},G=()=>{g("Send Invoice to Patient"),p(!0)},Z=()=>{ce.visit(`/payments?invoice_id=${t.id}`)},q=()=>{p(!1),g("")};return e.jsxs(xe,{children:[e.jsx(Y,{title:`Invoice #${t.id}`,children:e.jsx("style",{children:`
          @media print {
            body { -webkit-print-color-adjust: exact; }
            #invoice-content { 
              background: white !important;
              box-shadow: none !important;
              border-radius: 0 !important;
            }
            .no-print { display: none !important; }
          }
          
          #invoice-content {
            background: white;
            padding: 16px;
            font-family: system-ui, -apple-system, sans-serif;
            max-width: 100%;
            page-break-inside: avoid;
          }
          
          #invoice-content * {
            box-sizing: border-box;
          }
          
          #invoice-content .space-y-6 > * {
            margin-bottom: 16px !important;
          }
          
          #invoice-content .space-y-6 > *:last-child {
            margin-bottom: 0 !important;
          }
          
          #invoice-content .rounded-2xl {
            border-radius: 8px !important;
          }
          
          #invoice-content .p-6 {
            padding: 12px !important;
          }
          
          #invoice-content .gap-8 {
            gap: 16px !important;
          }
          
          #invoice-content .gap-6 {
            gap: 12px !important;
          }
          
          #invoice-content table {
            page-break-inside: auto;
          }
          
          #invoice-content tr {
            page-break-inside: avoid;
            page-break-after: auto;
          }
          
          #invoice-content .grid {
            page-break-inside: avoid;
          }
          
          /* Compact spacing for PDF */
          #invoice-content .space-y-4 > * {
            margin-bottom: 8px !important;
          }
          
          #invoice-content .space-y-3 > * {
            margin-bottom: 6px !important;
          }
          
          #invoice-content .py-4 {
            padding-top: 8px !important;
            padding-bottom: 8px !important;
          }
          
          #invoice-content .px-6 {
            padding-left: 12px !important;
            padding-right: 12px !important;
          }
        `})}),e.jsxs("div",{className:"max-w-5xl mx-auto space-y-6",children:[e.jsxs("div",{className:"flex items-center justify-between no-print",children:[e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsxs(J,{href:"/invoices",className:"flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors",children:[e.jsx(ee,{className:"h-5 w-5"}),e.jsx("span",{children:"Back to Invoices"})]}),e.jsx("div",{className:"h-6 w-px bg-gray-300"}),e.jsxs("h1",{className:"text-2xl font-bold text-gray-900",children:["Invoice #",t.id]})]}),e.jsxs("div",{className:"flex items-center space-x-2 bg-white/70 backdrop-blur-md p-2 rounded-xl shadow-sm border border-gray-200",children:[e.jsxs("div",{className:"flex items-center space-x-1 bg-gray-50 border border-gray-200 rounded-lg px-1",children:[e.jsx("button",{onClick:R,className:"flex items-center justify-center px-3 py-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-white transition-colors",title:"Print Invoice",children:e.jsx(k,{className:"h-4 w-4"})}),e.jsx("button",{onClick:H,disabled:i,className:"flex items-center justify-center px-3 py-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed",title:"Preview PDF",children:i?e.jsx(P,{className:"h-4 w-4 animate-spin"}):e.jsx(te,{className:"h-4 w-4"})}),e.jsx("button",{onClick:E,disabled:i,className:"flex items-center justify-center px-3 py-2 rounded-md text-gray-600 hover:text-blue-600 hover:bg-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed",title:"Download PDF",children:i?e.jsx(P,{className:"h-4 w-4 animate-spin"}):e.jsx(S,{className:"h-4 w-4"})})]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsxs("button",{onClick:G,className:"flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-lg shadow-sm hover:shadow-md transition-all",children:[e.jsx(se,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline font-medium",children:"Send"})]}),t.status!=="paid"&&e.jsxs("button",{onClick:Z,className:"flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-500 text-white rounded-lg shadow-sm hover:shadow-md transition-all",children:[e.jsx(I,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline font-medium",children:"Payment"})]})]})]})]}),e.jsxs("div",{id:"invoice-content",children:[e.jsx("div",{className:"bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-6 border border-gray-200",children:e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8",children:[e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("div",{className:"w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg",children:t.patient_name.charAt(0)}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-xl font-semibold text-gray-900",children:t.patient_name}),e.jsx("p",{className:"text-sm text-gray-500",children:"Patient"})]})]}),e.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-4",children:[e.jsxs("div",{className:"flex items-center space-x-2 text-sm",children:[e.jsx(ae,{className:"h-4 w-4 text-gray-400"}),e.jsx("span",{className:"text-gray-600",children:t.phone||"N/A"})]}),e.jsxs("div",{className:"flex items-center space-x-2 text-sm",children:[e.jsx(re,{className:"h-4 w-4 text-gray-400"}),e.jsx("span",{className:"text-gray-600",children:t.email||"N/A"})]}),e.jsxs("div",{className:"flex items-center space-x-2 text-sm",children:[e.jsx(o,{className:"h-4 w-4 text-gray-400"}),e.jsxs("span",{className:"text-gray-600",children:[t.encounter_type," Visit"]})]}),e.jsxs("div",{className:"flex items-center space-x-2 text-sm",children:[e.jsx(le,{className:"h-4 w-4 text-gray-400"}),e.jsx("span",{className:"text-gray-600",children:t.encounter_number})]})]})]}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-medium text-gray-500 uppercase",children:"Invoice Status"}),e.jsxs("div",{className:`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${B} mt-1`,children:[e.jsx($,{className:"w-4 h-4 mr-2"}),j]})]}),e.jsxs("div",{className:"text-right",children:[e.jsx("p",{className:"text-sm font-medium text-gray-500 uppercase",children:"Invoice Date"}),e.jsx("p",{className:"text-lg font-semibold text-gray-900",children:new Date(t.created_at).toLocaleDateString()})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-medium text-gray-500 uppercase",children:"Total Amount"}),e.jsxs("p",{className:"text-xl font-bold text-gray-900",children:["KSh ",new Intl.NumberFormat().format(t.total_amount)]})]}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-medium text-gray-500 uppercase",children:"Balance Due"}),e.jsxs("p",{className:`text-xl font-bold ${t.balance>0?"text-red-600":"text-green-600"}`,children:["KSh ",new Intl.NumberFormat().format(t.balance)]})]})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-gray-500",children:"Payment Progress"}),e.jsxs("span",{className:"font-medium",children:[y.toFixed(1),"%"]})]}),e.jsx("div",{className:"w-full bg-gray-200 rounded-full h-3",children:e.jsx("div",{className:"bg-gradient-to-r from-blue-500 to-green-500 h-3 rounded-full transition-all duration-300",style:{width:`${y}%`}})})]})]})]})}),e.jsxs("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden",children:[e.jsxs("div",{className:"px-6 py-4 border-b border-gray-200 bg-gray-50",children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900",children:"Invoice Line Items"}),e.jsx("p",{className:"text-sm text-gray-500 mt-1",children:"Detailed breakdown of all charges"})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"min-w-full divide-y divide-gray-200",children:[e.jsx("thead",{className:"bg-gray-50",children:e.jsxs("tr",{children:[e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"#"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Description"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Department"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Quantity"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Unit Price"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Total"}),e.jsx("th",{className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Date Added"})]})}),e.jsx("tbody",{className:"bg-white divide-y divide-gray-200",children:x.map((s,a)=>e.jsxs("tr",{className:a%2===0?"bg-white":"bg-gray-50",children:[e.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900",children:a+1}),e.jsx("td",{className:"px-6 py-4 whitespace-nowrap",children:e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("span",{className:"text-lg",children:C[s.item_type]||C.default}),e.jsxs("div",{children:[e.jsx("div",{className:"text-sm font-medium text-gray-900",children:s.description}),e.jsx("div",{className:"text-xs text-gray-500 capitalize",children:s.item_type})]})]})}),e.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize",children:s.item_type}),e.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-900",children:s.quantity}),e.jsxs("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-800",children:["KSh ",new Intl.NumberFormat().format(s.unit_price)]}),e.jsxs("td",{className:"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900",children:["KSh ",new Intl.NumberFormat().format(s.amount)]}),e.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500",children:new Date(s.created_at).toLocaleDateString()})]},s.id))})]})})]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",children:[e.jsxs("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 p-6",children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900 mb-4",children:"Payment Summary"}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-gray-600",children:"Subtotal"}),e.jsxs("span",{className:"font-medium text-gray-900",children:["KSh ",new Intl.NumberFormat().format(t.total_amount)]})]}),t.discount>0&&e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-gray-600",children:"Discount"}),e.jsxs("span",{className:"font-medium text-green-600",children:["-KSh ",new Intl.NumberFormat().format(t.discount)]})]}),e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-gray-600",children:"Net Amount"}),e.jsxs("span",{className:"font-medium text-gray-900",children:["KSh ",new Intl.NumberFormat().format(t.net_amount||t.total_amount)]})]}),e.jsx("div",{className:"border-t border-gray-200 pt-3",children:e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-gray-600",children:"Amount Paid"}),e.jsxs("span",{className:"font-medium text-green-600",children:["KSh ",new Intl.NumberFormat().format(t.paid_amount)]})]})}),e.jsx("div",{className:"border-t border-gray-200 pt-3",children:e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"text-lg font-semibold text-gray-900",children:"Balance Due"}),e.jsxs("span",{className:`text-lg font-bold ${t.balance>0?"text-red-600":"text-green-600"}`,children:["KSh ",new Intl.NumberFormat().format(t.balance)]})]})})]}),e.jsxs("div",{className:"mt-6 pt-6 border-t border-gray-200",children:[e.jsxs("div",{className:"flex items-center justify-center space-x-3 text-sm text-gray-500",children:[e.jsx(D,{className:"h-4 w-4"}),e.jsx("span",{children:"QR Code for Mobile Payment"})]}),e.jsx("div",{className:"mt-2 flex justify-center",children:e.jsx("div",{className:"w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center",children:e.jsx(D,{className:"h-8 w-8 text-gray-400"})})})]})]}),e.jsxs("div",{className:"bg-white rounded-2xl shadow-sm border border-gray-100 p-6",children:[e.jsxs("div",{className:"flex items-center justify-between mb-4",children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900",children:"Payment History"}),e.jsx(ne,{className:"h-5 w-5 text-gray-400"})]}),l.length>0?e.jsx("div",{className:"space-y-3",children:l.map(s=>e.jsxs("div",{className:"flex items-center justify-between p-3 bg-gray-50 rounded-lg",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"text-sm font-medium text-gray-900",children:["KSh ",new Intl.NumberFormat().format(s.amount)]}),e.jsxs("div",{className:"text-xs text-gray-500",children:[s.method," • ",s.reference_no]})]}),e.jsxs("div",{className:"text-right",children:[e.jsx("div",{className:"text-xs text-gray-500",children:new Date(s.created_at).toLocaleDateString()}),e.jsx("div",{className:"text-xs text-gray-400",children:new Date(s.created_at).toLocaleTimeString()})]})]},s.id))}):e.jsxs("div",{className:"text-center py-8",children:[e.jsx(I,{className:"h-12 w-12 text-gray-300 mx-auto mb-3"}),e.jsx("p",{className:"text-gray-500 text-sm",children:"No payments recorded yet"})]})]})]}),e.jsx("div",{className:"bg-gradient-to-r from-teal-50 to-blue-50 rounded-2xl p-6 border border-teal-100",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsx("div",{className:"w-12 h-12 bg-teal-600 rounded-lg flex items-center justify-center",children:e.jsx(o,{className:"h-6 w-6 text-white"})}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold text-gray-900",children:"MediCare Hospital"}),e.jsx("p",{className:"text-sm text-gray-600",children:"Professional Healthcare Services"})]})]}),e.jsxs("div",{className:"text-right text-sm text-gray-500",children:[e.jsxs("p",{children:["Generated on ",new Date().toLocaleDateString()]}),e.jsxs("p",{children:["Invoice #",t.id]})]})]})})]})," ",K&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2",children:e.jsxs("div",{className:"bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[95vh] flex flex-col",children:[e.jsxs("div",{className:"flex items-center justify-between p-4 border-b border-gray-200 flex-shrink-0",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900",children:"Print Preview"}),e.jsxs("p",{className:"text-sm text-gray-500",children:["Invoice #",t.id," - ",t.patient_name]})]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsxs("div",{className:"flex items-center space-x-2 bg-gray-100 rounded-lg p-1",children:[e.jsx("button",{onClick:()=>w("out"),disabled:d<=50,className:"p-2 hover:bg-white rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors",children:e.jsx(ie,{className:"h-4 w-4"})}),e.jsxs("span",{className:"text-sm font-medium px-2 min-w-[60px] text-center",children:[d,"%"]}),e.jsx("button",{onClick:()=>w("in"),disabled:d>=150,className:"p-2 hover:bg-white rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors",children:e.jsx(de,{className:"h-4 w-4"})})]}),e.jsxs("button",{onClick:U,className:"flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors",children:[e.jsx(k,{className:"h-4 w-4"}),e.jsx("span",{children:"Print"})]}),e.jsx("button",{onClick:M,className:"flex items-center justify-center w-10 h-10 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors",children:e.jsx(_,{className:"h-5 w-5"})})]})]}),e.jsx("div",{className:"flex-1 p-4 overflow-auto bg-gray-100",children:e.jsx("div",{className:"max-w-5xl mx-auto bg-white shadow-lg",style:{transform:`scale(${d/100})`,transformOrigin:"top center"},children:e.jsxs("div",{className:"p-12",children:[e.jsxs("div",{className:"text-center mb-12 border-b-2 border-gray-300 pb-8",children:[e.jsxs("div",{className:"flex items-center justify-center space-x-4 mb-6",children:[e.jsx("div",{className:"w-16 h-16 bg-teal-600 rounded-lg flex items-center justify-center",children:e.jsx(o,{className:"h-8 w-8 text-white"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-4xl font-bold text-gray-900",children:"MediCare Hospital"}),e.jsx("p",{className:"text-lg text-gray-600",children:"Professional Healthcare Services"})]})]}),e.jsxs("div",{className:"text-base text-gray-600 space-y-1",children:[e.jsx("p",{children:"123 Medical Center Drive, Nairobi, Kenya"}),e.jsx("p",{children:"Phone: +254 700 123 456 | Email: info@medicare.co.ke"})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-12 mb-12",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl font-bold text-gray-900 mb-6",children:"INVOICE"}),e.jsxs("div",{className:"space-y-3 text-lg",children:[e.jsxs("p",{children:[e.jsx("span",{className:"font-semibold",children:"Invoice #:"})," ",t.id]}),e.jsxs("p",{children:[e.jsx("span",{className:"font-semibold",children:"Date:"})," ",new Date(t.created_at).toLocaleDateString()]}),e.jsxs("p",{children:[e.jsx("span",{className:"font-semibold",children:"Encounter:"})," ",t.encounter_number]}),e.jsxs("p",{children:[e.jsx("span",{className:"font-semibold",children:"Status:"}),e.jsx("span",{className:`ml-2 px-3 py-1 rounded-full text-sm font-medium ${t.status==="paid"?"bg-green-100 text-green-800":t.status==="partial"?"bg-yellow-100 text-yellow-800":"bg-red-100 text-red-800"}`,children:j})]})]})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-4",children:"Bill To:"}),e.jsxs("div",{className:"space-y-2 text-lg",children:[e.jsx("p",{className:"text-2xl font-semibold text-gray-900",children:t.patient_name}),e.jsx("p",{className:"text-gray-700",children:t.phone||"N/A"}),e.jsx("p",{className:"text-gray-700",children:t.email||"N/A"}),e.jsxs("p",{className:"text-gray-700 font-medium",children:[t.encounter_type," Visit"]})]})]})]}),e.jsxs("div",{className:"mb-12",children:[e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-6",children:"Invoice Line Items"}),e.jsxs("table",{className:"w-full text-lg",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b-2 border-gray-300 bg-gray-50",children:[e.jsx("th",{className:"text-left py-4 px-4 font-semibold text-gray-900",children:"#"}),e.jsx("th",{className:"text-left py-4 px-4 font-semibold text-gray-900",children:"Description"}),e.jsx("th",{className:"text-center py-4 px-4 font-semibold text-gray-900",children:"Qty"}),e.jsx("th",{className:"text-right py-4 px-4 font-semibold text-gray-900",children:"Unit Price"}),e.jsx("th",{className:"text-right py-4 px-4 font-semibold text-gray-900",children:"Total"})]})}),e.jsx("tbody",{children:x.map((s,a)=>e.jsxs("tr",{className:`border-b border-gray-200 ${a%2===0?"bg-white":"bg-gray-50"}`,children:[e.jsx("td",{className:"py-4 px-4 font-medium",children:a+1}),e.jsx("td",{className:"py-4 px-4",children:e.jsxs("div",{children:[e.jsx("div",{className:"font-semibold text-gray-900",children:s.description}),e.jsx("div",{className:"text-base text-gray-600 capitalize mt-1",children:s.item_type})]})}),e.jsx("td",{className:"py-4 px-4 text-center font-medium",children:s.quantity}),e.jsxs("td",{className:"py-4 px-4 text-right",children:["KSh ",new Intl.NumberFormat().format(s.unit_price)]}),e.jsxs("td",{className:"py-4 px-4 text-right font-semibold",children:["KSh ",new Intl.NumberFormat().format(s.amount)]})]},s.id))})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-12",children:[e.jsx("div",{children:l.length>0&&e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-4",children:"Payment History"}),e.jsx("div",{className:"space-y-3",children:l.map(s=>e.jsxs("div",{className:"flex justify-between text-base bg-gray-50 p-3 rounded",children:[e.jsxs("span",{className:"font-medium",children:[s.method," - ",new Date(s.created_at).toLocaleDateString()]}),e.jsxs("span",{className:"font-semibold",children:["KSh ",new Intl.NumberFormat().format(s.amount)]})]},s.id))})]})}),e.jsx("div",{children:e.jsxs("div",{className:"bg-gray-50 p-6 rounded-lg",children:[e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-4",children:"Payment Summary"}),e.jsxs("div",{className:"space-y-3 text-lg",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"Subtotal:"}),e.jsxs("span",{className:"font-semibold",children:["KSh ",new Intl.NumberFormat().format(t.total_amount)]})]}),t.discount>0&&e.jsxs("div",{className:"flex justify-between text-green-600",children:[e.jsx("span",{className:"font-medium",children:"Discount:"}),e.jsxs("span",{className:"font-semibold",children:["-KSh ",new Intl.NumberFormat().format(t.discount)]})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"Net Amount:"}),e.jsxs("span",{className:"font-semibold",children:["KSh ",new Intl.NumberFormat().format(t.net_amount||t.total_amount)]})]}),e.jsxs("div",{className:"flex justify-between text-green-600",children:[e.jsx("span",{className:"font-medium",children:"Amount Paid:"}),e.jsxs("span",{className:"font-semibold",children:["KSh ",new Intl.NumberFormat().format(t.paid_amount)]})]}),e.jsxs("div",{className:"flex justify-between text-2xl font-bold border-t-2 border-gray-300 pt-4 mt-4",children:[e.jsx("span",{children:"Balance Due:"}),e.jsxs("span",{className:t.balance>0?"text-red-600":"text-green-600",children:["KSh ",new Intl.NumberFormat().format(t.balance)]})]})]})]})})]}),e.jsxs("div",{className:"mt-12 pt-8 border-t-2 border-gray-300 text-center",children:[e.jsx("p",{className:"text-lg text-gray-700 font-medium",children:"Thank you for choosing MediCare Hospital"}),e.jsxs("p",{className:"text-base text-gray-600 mt-2",children:["Generated on ",new Date().toLocaleDateString()]})]})]})})})]})}),L&&n&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2",children:e.jsxs("div",{className:"bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[95vh] flex flex-col",children:[e.jsxs("div",{className:"flex items-center justify-between p-4 border-b border-gray-200 flex-shrink-0",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-gray-900",children:"PDF Preview"}),e.jsxs("p",{className:"text-sm text-gray-500",children:["Invoice #",t.id," - ",t.patient_name]})]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsxs("button",{onClick:T,className:"flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors",children:[e.jsx(S,{className:"h-4 w-4"}),e.jsx("span",{children:"Download"})]}),e.jsx("button",{onClick:O,className:"flex items-center justify-center w-10 h-10 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors",children:e.jsx(_,{className:"h-5 w-5"})})]})]}),e.jsx("div",{className:"flex-1 p-4 overflow-hidden",children:e.jsx("div",{className:"w-full h-full bg-gray-100 rounded-lg overflow-hidden",children:e.jsx("iframe",{src:URL.createObjectURL(n),className:"w-full h-full border-0",title:"Invoice Preview",style:{minHeight:"600px"}})})})]})}),z&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",children:e.jsx("div",{className:"bg-white rounded-2xl shadow-2xl max-w-md w-full p-6",children:e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4",children:e.jsx(oe,{className:"h-8 w-8 text-blue-600"})}),e.jsx("h3",{className:"text-xl font-semibold text-gray-900 mb-2",children:"Coming Soon!"}),e.jsx("p",{className:"text-gray-600 mb-2",children:A}),e.jsx("p",{className:"text-sm text-gray-500 mb-6",children:"This feature is currently under development. We're working hard to bring you the best hospital management experience."}),e.jsx("button",{onClick:q,className:"w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors",children:"Got it!"})]})})})]})]})}export{fe as default};
