import{j as o}from"./react-vendor-CB1DGefZ.js";function s(r){return o.jsx("div",{children:"Placeholder for Modal"})}export{s as M};
