import{j as o}from"./react-vendor-CB1DGefZ.js";function p(r){return o.jsx("div",{children:"Placeholder for ApplicationLogo"})}export{p as A};
