import{j as t}from"./react-vendor-CB1DGefZ.js";import{m}from"./framer-motion-BvyGw6a9.js";function f({children:o,variant:i="primary",size:l="md",icon:e,iconPosition:s="left",gradient:a,loading:n=!1,disabled:r=!1,className:d="",onClick:x,type:p="button"}){const g={primary:"button-premium",secondary:"button-secondary",outline:"border-2 border-teal-500 text-teal-600 dark:text-teal-400 bg-transparent hover:bg-teal-50 dark:hover:bg-teal-900/20",ghost:"text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800",gradient:a?`bg-gradient-to-r ${a} text-white`:"button-premium"},b={sm:"px-4 py-2 text-sm rounded-xl",md:"px-6 py-3 text-sm rounded-2xl",lg:"px-8 py-4 text-base rounded-2xl",xl:"px-10 py-5 text-lg rounded-3xl"};return t.jsx(m.button,{whileHover:{scale:r?1:1.05},whileTap:{scale:r?1:.95},initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{type:"spring",stiffness:300,damping:30},type:p,onClick:x,disabled:r||n,className:`
        ${g[i]}
        ${b[l]}
        font-semibold
        transition-all duration-300
        transform
        shadow-lg
        hover:shadow-xl
        disabled:opacity-50
        disabled:cursor-not-allowed
        disabled:transform-none
        flex items-center justify-center gap-3
        ${d}
      `,children:n?t.jsx(m.div,{animate:{rotate:360},transition:{duration:1,repeat:1/0,ease:"linear"},className:"w-5 h-5 border-2 border-current border-t-transparent rounded-full"}):t.jsxs(t.Fragment,{children:[e&&s==="left"&&t.jsx(e,{className:"w-5 h-5"}),o,e&&s==="right"&&t.jsx(e,{className:"w-5 h-5"})]})})}function y({children:o,variant:i="primary",size:l="md",icon:e,pulse:s=!1,gradient:a,className:n=""}){const r={primary:"bg-gradient-to-r from-teal-500 to-cyan-600 text-white",secondary:"bg-gradient-to-r from-slate-500 to-gray-600 text-white",success:"bg-gradient-to-r from-emerald-500 to-teal-600 text-white",warning:"bg-gradient-to-r from-yellow-500 to-orange-600 text-white",danger:"bg-gradient-to-r from-red-500 to-pink-600 text-white",info:"bg-gradient-to-r from-blue-500 to-indigo-600 text-white",outline:"border-2 border-teal-500 text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/20"},d={sm:"px-2 py-1 text-xs",md:"px-3 py-1 text-sm",lg:"px-4 py-2 text-base"};return t.jsxs(m.span,{initial:{opacity:0,scale:.8},animate:{opacity:1,scale:1},transition:{type:"spring",stiffness:300,damping:30},className:`
        inline-flex items-center gap-2 rounded-full font-bold shadow-md
        ${a?`bg-gradient-to-r ${a} text-white`:r[i]}
        ${d[l]}
        ${s?"animate-pulse":""}
        ${n}
      `,children:[e&&t.jsx(e,{className:"w-4 h-4"}),o]})}export{y as P,f as a};
