const r=i=>i==null||isNaN(i)?"KES 0.00":`KES ${Number(i).toLocaleString("en-KE",{minimumFractionDigits:2,maximumFractionDigits:2})}`;export{r as f};
