import{j as a,r as p}from"./react-vendor-CB1DGefZ.js";import{m as s}from"./framer-motion-BvyGw6a9.js";function b({children:i,className:r="",variant:t="default",hover:e=!0,gradient:l,onClick:d}){const o={default:"card-premium",compact:"card-compact",feature:"card-feature",glass:"glass-card rounded-3xl p-6"},n=e?{whileHover:{scale:1.02,y:-4,transition:{type:"spring",stiffness:300,damping:30}},whileTap:{scale:.98}}:{};return a.jsx(s.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},...n,onClick:d,className:`
        ${o[t]} 
        ${l?`bg-gradient-to-br ${l}`:""}
        ${d?"cursor-pointer":""}
        ${r}
      `,children:i})}const u=p.forwardRef(({label:i,error:r,icon:t,iconPosition:e="left",variant:l="default",className:d="",containerClassName:o="",...n},m)=>{const c={default:"input-premium",glass:"bg-white/80 dark:bg-slate-800/80 backdrop-blur-lg border border-white/40 dark:border-slate-600/40 rounded-2xl",outline:"bg-transparent border-2 border-slate-300 dark:border-slate-600 rounded-2xl focus:border-teal-500 dark:focus:border-teal-400"};return a.jsxs(s.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.3},className:`space-y-2 ${o}`,children:[i&&a.jsx(s.label,{initial:{opacity:0,x:-10},animate:{opacity:1,x:0},transition:{delay:.1},className:"block text-sm font-semibold text-slate-700 dark:text-slate-300",children:i}),a.jsxs("div",{className:"relative",children:[t&&e==="left"&&a.jsx("div",{className:"absolute left-4 top-1/2 transform -translate-y-1/2 z-10",children:a.jsx(t,{className:"w-5 h-5 text-slate-400"})}),a.jsx(s.input,{ref:m,whileFocus:{scale:1.02},transition:{type:"spring",stiffness:300,damping:30},className:`
            w-full
            ${c[l]}
            ${t&&e==="left"?"pl-12":""}
            ${t&&e==="right"?"pr-12":""}
            ${r?"border-red-500 focus:border-red-500 focus:ring-red-500/50":""}
            ${d}
          `,...n}),t&&e==="right"&&a.jsx("div",{className:"absolute right-4 top-1/2 transform -translate-y-1/2 z-10",children:a.jsx(t,{className:"w-5 h-5 text-slate-400"})})]}),r&&a.jsx(s.p,{initial:{opacity:0,y:-10},animate:{opacity:1,y:0},className:"text-sm text-red-600 dark:text-red-400 font-medium",children:r})]})});u.displayName="PremiumInput";export{b as P,u as a};
